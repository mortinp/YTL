<?php
    App::uses('AppModel', 'Model');
    
    class Search extends AppModel{
        public $useTable = false;
    }
?>
