<?php
App::uses('AppModel', 'Model');
class UrlInvitation extends AppModel {
    
    public $useTable = 'x_url_invitations';
}

?>