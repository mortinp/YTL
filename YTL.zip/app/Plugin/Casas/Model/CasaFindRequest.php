<?php
App::uses('AppModel', 'Model');
class CasaFindRequest extends AppModel {
    
    public $useTable = 'casas_find_requests';
    
}

?>