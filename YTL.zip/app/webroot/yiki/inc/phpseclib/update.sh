#!/bin/sh

wget -nv https://raw.github.com/phpseclib/phpseclib/master/LICENSE -O LICENSE
wget -nv https://raw.github.com/phpseclib/phpseclib/master/phpseclib/Math/BigInteger.php -O Math_BigInteger.php
wget -nv https://raw.github.com/phpseclib/phpseclib/master/phpseclib/Crypt/AES.php -O Crypt_AES.php
wget -nv https://raw.github.com/phpseclib/phpseclib/master/phpseclib/Crypt/Rijndael.php -O Crypt_Rijndael.php
wget -nv https://raw.github.com/phpseclib/phpseclib/master/phpseclib/Crypt/Base.php -O Crypt_Base.php
wget -nv https://raw.github.com/phpseclib/phpseclib/master/phpseclib/Crypt/Hash.php -O Crypt_Hash.php
