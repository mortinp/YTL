<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Antonio Castilla <antoniocastilla@trazoide.com>
 */
$lang['testfailed']            = 'Lo sentimos, pero el CAPTCHA no fue respondido correctamente. Tal vez no eres una persona.';
$lang['fillcaptcha']           = 'Por favor, complete todas las letras de la caja para demostrar que eres una persona.';
$lang['fillmath']              = 'Por favor, resuelve la siguiente ecuación para demostrar que eres una persona.';
$lang['soundlink']             = 'Si no puede leer toda las letras de la imagen, descargue el archivo wav que lo leerá por ti.';
$lang['honeypot']              = 'Por favor, mantenga este campo vacío: ';
